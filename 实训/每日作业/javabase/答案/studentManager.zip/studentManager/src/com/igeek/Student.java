package com.igeek;

/**  
* @ClassName: Student  
* @Description: ѧ����
* Company www.igeekhome.com
*    
*/
public class Student {
	/**  
	* @Fields id : ѧ��  
	*/  
	private String id;
	/**  
	* @Fields name : ����  
	*/  
	private String name;
	/**  
	* @Fields age : ����  
	*/  
	private String age;
	/**  
	* @Fields address : ��ס��  
	*/  
	private String address;
	/**  
	* @Title: Student      
	*/
	public Student() {
	}
	/**  
	* @Title: Student  
	* @param id
	* @param name
	* @param age
	* @param address    
	*/
	public Student(String id, String name, String age, String address) {
		this.id = id;
		this.name = name;
		this.age = age;
		this.address = address;
	}
	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the age
	 */
	public String getAge() {
		return age;
	}
	/**
	 * @param age the age to set
	 */
	public void setAge(String age) {
		this.age = age;
	}
	/**
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}
	/**
	 * @param address the address to set
	 */
	public void setAddress(String address) {
		this.address = address;
	}

}