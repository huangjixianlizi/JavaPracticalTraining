package com.igeek03;

import java.awt.datatransfer.FlavorEvent;
import java.util.ArrayList;

/**
 * @ClassName: Meal
 * @Description: TODO(������һ�仰��������������)
 * @date 2018��8��24�� ����2:19:38 Company www.igeekhome.com
 * 
 */
public class Meal {
	private ArrayList<Item> items = new ArrayList<Item>();
	private String name;

	public Meal() {

	}

	public Meal(String name) {
		this.name = name;
	}

	public void addItem(Item item) {
		items.add(item);
	}

	public String getName() {
		return name;
	}

	public float totoalPrice() {
		float result = 0;
		for (Item item : items) {
			result += item.price();
		}
		return result;
	}
	public void showInfo(){
		System.out.println(this.name);
		for(Item item:items){
			System.out.println(item.toString());
		}
		System.out.println("�ܼ�:"+totoalPrice());
	}
}
