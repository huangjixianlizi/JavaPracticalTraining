package com.igeek03;

/**
 * @ClassName: MyHashSetDemo
 * @Description: TODO(������һ�仰��������������)
 * @date 2018��8��22�� ����2:34:02 Company www.igeekhome.com
 * 
 */
public class MyHashSetDemo {
	public static void main(String[] args) {
		MyHashSet<String> myHashSet = new MyHashSet<String>();
		myHashSet.add(0, "00");
		myHashSet.add(1, "11");
		myHashSet.addFirst("33");
		myHashSet.addLast("44");
		myHashSet.add(4,"55");
		myHashSet.add(6,"66");
		myHashSet.add(-100,"77");
		System.out.println(myHashSet);
		System.out.println(myHashSet.getFirst());
		System.out.println(myHashSet.getLast());
		System.out.println(myHashSet.get(1));
		
		myHashSet.remove(1);
		System.out.println(myHashSet);
		myHashSet.removeFirst();
		myHashSet.removeLast();
		System.out.println(myHashSet);
		
		myHashSet.add(1,"00");
		System.out.println(myHashSet);
	}
}
