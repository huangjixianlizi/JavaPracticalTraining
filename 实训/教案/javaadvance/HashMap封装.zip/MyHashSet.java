package com.igeek03;

import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;

/**
 * @ClassName: MyHashSet
 * @Description: TODO(������һ�仰��������������)
 * @date 2018��8��22�� ����2:09:44 Company www.igeekhome.com
 * 
 */
public class MyHashSet<E> extends HashSet<E> {
	/**  
	* @Fields serialVersionUID : TODO(��һ�仰�������������ʾʲô)  
	*/  
	private static final long serialVersionUID = 1L;

	public MyHashSet() {
		super();
	}

	public MyHashSet(Collection<? extends E> c) {
		super(c);
	}

	public MyHashSet(int initialCapacity, float loadFactor) {
		super(initialCapacity, loadFactor);
	}

	public MyHashSet(int initialCapacity) {
		super(initialCapacity);
	}

	public boolean remove(int index) {
		E e = get(index);
		if (e != null) {
			return remove(e);
		}
		return false;
	}

	public boolean removeFirst() {
		return remove(0);
	}

	public boolean removeLast() {
		return remove(size() - 1);
	}

	public E get(int index) {
		int id = 0;
		Iterator<E> iterator = this.iterator();
		while (iterator.hasNext()) {
			E e = iterator.next();
			if (id == index) {
				return e;
			}
			id++;
		}
		return null;
	}

	public E getFirst() {
		return get(0);
	}

	public E getLast() {
		return get(size() - 1);
	}

	public boolean addFirst(E e) {
		return add(0, e);
	}

	public boolean addLast(E e) {
		return add(size(), e);
	}

	public boolean add(int index, E e) {
		if (index < 0) {
			index = 0;
		}
		if (index >= size()) {
			return add(e);
		}
		HashSet<E> newset = new HashSet<E>();
		Iterator<E> iterator = this.iterator();
		while (iterator.hasNext()) {
			newset.add(iterator.next());
		}
		this.clear();
		int id = 0;
		Iterator<E> iterator2 = newset.iterator();
		while (iterator2.hasNext()) {
			E e2 = iterator2.next();
			if (id == index) {
				this.add(e);
			} else if (e2 == e) {
				continue;
			}
			this.add(e2);
			id++;
		}
		return true;
	}

}
